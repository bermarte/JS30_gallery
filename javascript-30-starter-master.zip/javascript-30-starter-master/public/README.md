# Public

All styles, images, sounds, assets, ... go here. If it's not JavaScript and you need it for your web page, it goes here.
